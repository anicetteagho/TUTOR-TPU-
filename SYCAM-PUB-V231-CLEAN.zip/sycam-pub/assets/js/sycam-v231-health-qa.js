/*! SYCAM V231 — Santé système + checklist QA (pack clean) */
(function (global) {
  "use strict";

  var VERSION = "231.0.0-health-qa";

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function checks() {
    var rows = [];
    function add(name, ok, detail) {
      rows.push({ name: name, ok: !!ok, detail: detail || "" });
    }
    add("Core minimal", !!global.SycamV210, global.SycamV210 && global.SycamV210.version);
    add("Shell mobile V219", !!global.SycamV219, global.SycamV219 && global.SycamV219.version);
    add("Fil / Explorer V220", !!global.SycamV220);
    add("Publier V221", !!global.SycamV221);
    add("Réseau V222", !!global.SycamV222);
    add("Stories V223", !!global.SycamV223);
    add("Notifications V224", !!global.SycamV224);
    add("Démo V225", !!global.SycamV225);
    add("Hors-ligne V226", !!global.SycamV226);
    add("PWA V227", !!global.SycamV227);
    add("Plus hub V228", !!global.SycamV228);
    add("Onboarding V229", !!global.SycamV229);
    add("Raccourcis / News V230", !!global.SycamV230);
    add(
      "localStorage",
      (function () {
        try {
          localStorage.setItem("__t", "1");
          localStorage.removeItem("__t");
          return true;
        } catch (e) {
          return false;
        }
      })()
    );
    add("Service Worker API", "serviceWorker" in navigator);
    add("SW contrôlé", !!(navigator.serviceWorker && navigator.serviceWorker.controller));
    add(
      "Online",
      typeof navigator.onLine === "boolean" ? navigator.onLine : true,
      navigator.onLine ? "en ligne" : "hors-ligne"
    );
    add(
      "Standalone PWA",
      global.SycamV227 && global.SycamV227.isStandalone && global.SycamV227.isStandalone()
    );
    add(
      "Mandat",
      global.SycamV212 && global.SycamV212.getMandate && global.SycamV212.getMandate().accepted,
      "conformité"
    );
    var pass = rows.filter(function (r) {
      return r.ok;
    }).length;
    return {
      rows: rows,
      pass: pass,
      total: rows.length,
      score: Math.round((pass / rows.length) * 100)
    };
  }

  function ensureStyles() {
    if ($("sycam-v231-css")) return;
    var s = document.createElement("style");
    s.id = "sycam-v231-css";
    s.textContent =
      "#pg-health-v231{padding:14px 14px 100px;max-width:720px;margin:0 auto;background:#0b1220;color:#e2e8f0;min-height:100vh;display:none;box-sizing:border-box}" +
      "#pg-health-v231.on{display:block}" +
      "#pg-health-v231 h1{margin:0 0 4px;font-size:20px;color:#fff}" +
      ".v231-sub{font-size:12px;color:#94a3b8;margin:0 0 12px}" +
      ".v231-score{font-size:36px;font-weight:800;color:#2dd4bf;margin:8px 0}" +
      ".v231-row{display:flex;justify-content:space-between;gap:8px;padding:10px 0;border-bottom:1px solid #1f2937;font-size:13px}" +
      ".v231-ok{color:#34d399}.v231-no{color:#f87171}" +
      ".v231-actions button{border:0;border-radius:10px;padding:12px 14px;font-weight:700;margin:4px 4px 0 0;background:#1f2937;color:#e2e8f0;cursor:pointer;min-height:44px}" +
      ".v231-actions button.primary{background:#0d7377;color:#fff}";
    document.head.appendChild(s);
  }

  function openHealth() {
    ensureStyles();
    if (global.SycamV219 && global.SycamV219.ensureChrome) global.SycamV219.ensureChrome();
    document.querySelectorAll("section.page,.page").forEach(function (p) {
      p.classList.remove("on");
      if (p.style) p.style.display = "none";
    });
    var page = $("pg-health-v231");
    if (!page) {
      page = document.createElement("section");
      page.id = "pg-health-v231";
      page.className = "page";
      (document.querySelector("main") || document.body).appendChild(page);
    }
    page.style.display = "block";
    page.classList.add("on");

    var r = checks();
    var listHtml = r.rows
      .map(function (row) {
        var cls = row.ok ? "v231-ok" : "v231-no";
        var mark = row.ok ? "OK" : "-";
        var detail = row.detail
          ? ' <small style="color:#64748b">(' + esc(row.detail) + ")</small>"
          : "";
        return (
          '<div class="v231-row"><span>' +
          esc(row.name) +
          detail +
          '</span><span class="' +
          cls +
          '">' +
          mark +
          "</span></div>"
        );
      })
      .join("");

    page.innerHTML =
      "<h1>Sante systeme</h1>" +
      '<p class="v231-sub">Checklist QA - pack clean V231</p>' +
      '<div class="v231-score">' +
      r.score +
      "%</div>" +
      '<div style="font-size:12px;color:#94a3b8;margin-bottom:12px">' +
      r.pass +
      " / " +
      r.total +
      " controles OK</div>" +
      listHtml +
      '<div class="v231-actions" style="margin-top:16px">' +
      '<button type="button" class="primary" id="v231Refresh">Rafraichir</button>' +
      '<button type="button" id="v231Home">Accueil</button>' +
      '<button type="button" id="v231Demo">Demo 5 min</button>' +
      '<button type="button" id="v231Plus">Menu Plus</button>' +
      "</div>";

    $("v231Refresh").onclick = openHealth;
    $("v231Home").onclick = function () {
      if (global.SycamV219) global.SycamV219.openMobileHome();
    };
    $("v231Demo").onclick = function () {
      if (global.SycamV225) global.SycamV225.openDemo();
    };
    $("v231Plus").onclick = function () {
      if (global.SycamV228) global.SycamV228.openPlusHub();
    };
  }

  function patchPlus() {
    if (!global.SycamV228 || global.SycamV228.__health231) return;
    var orig = global.SycamV228.openPlusHub;
    if (typeof orig !== "function") return;
    global.SycamV228.openPlusHub = function () {
      orig.apply(global.SycamV228, arguments);
      setTimeout(function () {
        var page = $("pg-plusmenu");
        if (!page || page.querySelector("#v231HealthBtn")) return;
        var card = document.createElement("div");
        card.className = "v219-card";
        card.innerHTML =
          '<h3>Qualite</h3><div class="v219-grid-2">' +
          '<button type="button" class="v219-tile" id="v231HealthBtn"><span class="t-ico">OK</span><span class="t-label">Sante</span><span class="t-hint">Checklist QA</span></button>' +
          "</div>";
        page.appendChild(card);
        $("v231HealthBtn").onclick = openHealth;
      }, 40);
    };
    global.SycamV228.__health231 = true;
  }

  function boot() {
    patchPlus();
    setTimeout(patchPlus, 500);
    if (typeof global.go === "function" && !global.__sycamV231Go) {
      global.__sycamV231Go = true;
      var orig = global.go;
      global.go = function (name) {
        var n = String(name || "").toLowerCase();
        if (n === "health" || n === "sante" || n === "qa") {
          openHealth();
          return;
        }
        return orig.apply(this, arguments);
      };
    }
    console.log("[V231] Health QA", VERSION, checks().score + "%");
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV231 = {
    version: VERSION,
    openHealth: openHealth,
    checks: checks
  };
})(typeof window !== "undefined" ? window : this);
