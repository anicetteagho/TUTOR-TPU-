/*! SYCAM V225 — sycam-v225-demo-walkthrough.js
 * Parcours démo 5 minutes :
 *  1 Mandat  2 Publier  3 Story  4 Message  5 Notifs  6 Mission
 */
(function (global) {
  "use strict";

  var VERSION = "225.0.0-demo-walkthrough";
  var STEP_KEY = "sycam_demo_step_v225";

  var STEPS = [
    {
      id: "mandate",
      title: "1 · Conformité",
      text: "Acceptez le mandat local pour activer les écritures protégées (gates).",
      actionLabel: "Ouvrir conformité",
      run: function () {
        if (global.SycamV212 && global.SycamV212.openLegal) global.SycamV212.openLegal();
        else toast("Module V212 absent");
      }
    },
    {
      id: "publish",
      title: "2 · Publier",
      text: "Créez un article démo (titre + résumé). Il alimentera le fil Accueil.",
      actionLabel: "Ouvrir Publier",
      run: function () {
        if (global.SycamV221 && global.SycamV221.openPublish)
          global.SycamV221.openPublish("article");
        else toast("Module V221 absent");
      },
      auto: function () {
        // seed a demo post if empty
        try {
          if (global.SycamV210 && global.SycamV210.putResource) {
            global.SycamV210.putResource({
              type: "publication",
              title: "Démo SYCAM · Article d’exemple",
              source: "demo",
              meta: {
                abstract: "Publication générée par le parcours démo V225.",
                type: "article"
              },
              capabilities: ["read"]
            });
          }
        } catch (e) {}
      }
    },
    {
      id: "story",
      title: "3 · Story",
      text: "Publiez un statut (texte). Il apparaît dans la barre Accueil (24 h).",
      actionLabel: "Créer une story",
      run: function () {
        if (global.SycamV223 && global.SycamV223.addStory) {
          global.SycamV223.addStory({
            type: "text",
            text: "SYCAM-PUB en démo — unifier · publier · innover 🚀"
          });
          toast("Story démo ajoutée");
          if (global.SycamV219) global.SycamV219.openMobileHome();
          setTimeout(function () {
            if (global.SycamV223.injectIntoHome) global.SycamV223.injectIntoHome();
          }, 100);
        } else if (global.SycamV223 && global.SycamV223.openCreate) {
          global.SycamV223.openCreate();
        }
      }
    },
    {
      id: "message",
      title: "4 · Réseau",
      text: "Ouvrez le chat d’un contact et envoyez un message local.",
      actionLabel: "Ouvrir Réseau",
      run: function () {
        if (global.SycamV222 && global.SycamV222.openNetwork)
          global.SycamV222.openNetwork({ view: "list" });
        else toast("Module V222 absent");
      }
    },
    {
      id: "notifs",
      title: "5 · Notifications",
      text: "La cloche agrège pubs, stories et messages. Ouvrez le panneau.",
      actionLabel: "Voir notifications",
      run: function () {
        if (global.SycamV224 && global.SycamV224.pushNotif) {
          global.SycamV224.pushNotif({
            title: "Démo terminée bientôt",
            body: "Vous avez parcouru le parcours SYCAM-PUB.",
            action: "home"
          });
        }
        if (global.SycamV224 && global.SycamV224.openPanel) global.SycamV224.openPanel();
        else toast("Module V224 absent");
      }
    },
    {
      id: "mission",
      title: "6 · Mission Control",
      text: "Vue unique : score labo, mandat, gates, appareil, file.",
      actionLabel: "Mission Control",
      run: function () {
        if (global.SycamV219 && global.SycamV219.openMissionControl)
          global.SycamV219.openMissionControl();
        else toast("Mission Control V219 absent");
      }
    }
  ];

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function toast(msg) {
    if (typeof global.showToast === "function") {
      try {
        global.showToast(msg);
        return;
      } catch (e) {}
    }
    var t = $("toast");
    if (t) {
      t.textContent = msg;
      t.classList.add("on");
      setTimeout(function () {
        t.classList.remove("on");
      }, 2000);
    }
  }
  function getStep() {
    try {
      return parseInt(localStorage.getItem(STEP_KEY) || "0", 10) || 0;
    } catch (e) {
      return 0;
    }
  }
  function setStep(i) {
    try {
      localStorage.setItem(STEP_KEY, String(i));
    } catch (e) {}
  }

  function ensureStyles() {
    if ($("sycam-v225-css")) return;
    var s = document.createElement("style");
    s.id = "sycam-v225-css";
    s.textContent = [
      "#pg-demo-v225{padding:16px 14px 100px;max-width:720px;margin:0 auto;background:#0b1220;color:#e2e8f0;min-height:100vh;display:none;box-sizing:border-box}",
      "#pg-demo-v225.on{display:block}",
      "#pg-demo-v225 h1{margin:0 0 4px;font-size:20px;color:#fff}",
      ".v225-sub{font-size:12px;color:#94a3b8;margin:0 0 14px}",
      ".v225-card{background:#111827;border:1px solid #1f2937;border-radius:14px;padding:16px;margin-bottom:12px}",
      ".v225-card h3{margin:0 0 8px;font-size:15px;color:#2dd4bf}",
      ".v225-card p{margin:0 0 12px;font-size:13px;line-height:1.45;color:#cbd5e1}",
      ".v225-steps{display:flex;gap:4px;margin-bottom:14px}",
      ".v225-steps i{flex:1;height:4px;border-radius:2px;background:#1f2937}",
      ".v225-steps i.on{background:#0d7377}",
      ".v225-steps i.done{background:#2dd4bf}",
      ".v225-actions button{border:0;border-radius:10px;padding:12px 14px;font-weight:700;font-size:13px;cursor:pointer;background:#1f2937;color:#e2e8f0;margin:0 8px 8px 0;min-height:44px}",
      ".v225-actions button.primary{background:#0d7377;color:#fff}",
      "#v225Fab{position:fixed;right:14px;bottom:calc(72px + env(safe-area-inset-bottom,0px));z-index:60;border:0;border-radius:999px;padding:12px 16px;background:#7c3aed;color:#fff;font-weight:800;font-size:12px;box-shadow:0 4px 16px rgba(124,58,237,.4);cursor:pointer}"
    ].join("");
    document.head.appendChild(s);
  }

  function showPage(id) {
    ensureStyles();
    document.querySelectorAll("section.page,.page").forEach(function (p) {
      p.classList.remove("on");
      if (p.style) p.style.display = "none";
    });
    var page = $(id);
    if (!page) {
      page = document.createElement("section");
      page.id = id;
      page.className = "page";
      (document.querySelector("main") || document.body).appendChild(page);
    }
    page.style.display = "block";
    page.classList.add("on");
    return page;
  }

  function openDemo() {
    if (global.SycamV219 && global.SycamV219.ensureChrome) global.SycamV219.ensureChrome();
    var i = getStep();
    if (i >= STEPS.length) i = 0;
    render(i);
  }

  function render(i) {
    setStep(i);
    var step = STEPS[i];
    var page = showPage("pg-demo-v225");
    var bars = STEPS.map(function (_, idx) {
      var cls = idx < i ? "done" : idx === i ? "on" : "";
      return "<i class='" + cls + "'></i>";
    }).join("");

    page.innerHTML =
      "<h1>Démo 5 minutes</h1>" +
      '<p class="v225-sub">Parcours guidé · étape ' +
      (i + 1) +
      "/" +
      STEPS.length +
      "</p>" +
      '<div class="v225-steps">' +
      bars +
      "</div>" +
      '<div class="v225-card"><h3>' +
      esc(step.title) +
      "</h3><p>" +
      esc(step.text) +
      '</p><div class="v225-actions">' +
      '<button type="button" class="primary" id="v225Act">' +
      esc(step.actionLabel) +
      "</button>" +
      '<button type="button" id="v225Next">' +
      (i + 1 < STEPS.length ? "Étape suivante →" : "Terminer") +
      "</button>" +
      (i > 0 ? '<button type="button" id="v225Prev">← Retour</button>' : "") +
      '<button type="button" id="v225Skip">Réinitialiser</button>' +
      "</div></div>" +
      '<div class="v225-card"><h3>Checklist modules</h3>' +
      checklistHtml() +
      "</div>";

    $("v225Act").onclick = function () {
      if (step.auto) {
        try {
          step.auto();
        } catch (e) {}
      }
      step.run();
    };
    $("v225Next").onclick = function () {
      if (i + 1 < STEPS.length) render(i + 1);
      else {
        setStep(0);
        toast("Démo terminée — bravo");
        if (global.SycamV224 && global.SycamV224.pushNotif) {
          global.SycamV224.pushNotif({
            title: "Parcours démo complété",
            body: "SYCAM-PUB V225",
            action: "home"
          });
        }
        if (global.SycamV219) global.SycamV219.openMobileHome();
      }
    };
    if ($("v225Prev"))
      $("v225Prev").onclick = function () {
        render(Math.max(0, i - 1));
      };
    $("v225Skip").onclick = function () {
      setStep(0);
      render(0);
      toast("Démo réinitialisée");
    };
  }

  function checklistHtml() {
    var mods = [
      ["V212 Conformité", !!global.SycamV212],
      ["V219 Shell mobile", !!global.SycamV219],
      ["V220 Fil / Explorer", !!global.SycamV220],
      ["V221 Publier", !!global.SycamV221],
      ["V222 Réseau", !!global.SycamV222],
      ["V223 Stories", !!global.SycamV223],
      ["V224 Notifications", !!global.SycamV224]
    ];
    return mods
      .map(function (m) {
        return (
          '<div style="font-size:12px;padding:6px 0;border-bottom:1px solid #1f2937">' +
          (m[1] ? "✅ " : "⬜ ") +
          esc(m[0]) +
          "</div>"
        );
      })
      .join("");
  }

  function ensureFab() {
    if ($("v225Fab")) return;
    ensureStyles();
    var b = document.createElement("button");
    b.id = "v225Fab";
    b.type = "button";
    b.textContent = "Démo 5 min";
    b.onclick = openDemo;
    document.body.appendChild(b);
  }

  function boot() {
    setTimeout(ensureFab, 500);
    if (global.SycamV205 && global.SycamV205.MANIFESTS) {
      global.SycamV205.MANIFESTS["sycam-v225"] = {
        id: "sycam-v225",
        version: VERSION,
        global: "SycamV225",
        requires: ["sycam-v224"],
        provides: ["demo.walkthrough"],
        modifies: [],
        routes: ["demo", "walkthrough"],
        storage: [STEP_KEY],
        events: [],
        permissions: ["demo.local"],
        adr: ["ADR-027"]
      };
    }
    if (global.SycamV204 && global.SycamV204.DECLARED_DEPS) {
      global.SycamV204.DECLARED_DEPS.SycamV225 = ["SycamV224"];
    }
    if (typeof global.go === "function" && !global.__sycamV225Go) {
      global.__sycamV225Go = true;
      var orig = global.go;
      global.go = function (name) {
        var n = String(name || "").toLowerCase();
        if (n === "demo" || n === "walkthrough") {
          openDemo();
          return;
        }
        return orig.apply(this, arguments);
      };
    }
    // Plus menu tip via notif once
    try {
      if (!sessionStorage.getItem("sycam_v225_tip")) {
        sessionStorage.setItem("sycam_v225_tip", "1");
        setTimeout(function () {
          if (global.SycamV224 && global.SycamV224.pushNotif) {
            global.SycamV224.pushNotif({
              title: "Astuce",
              body: "Bouton violet « Démo 5 min » en bas à droite.",
              action: "home"
            });
          }
        }, 2000);
      }
    } catch (e) {}
    console.log("[V225] Demo walkthrough", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV225 = {
    version: VERSION,
    openDemo: openDemo,
    STEPS: STEPS
  };
})(typeof window !== "undefined" ? window : this);
