/*! SYCAM V224 — sycam-v224-local-notifications.js
 * Centre de notifications local :
 *  - Badge cloche header
 *  - Agrégation pubs / messages / gates / stories
 *  - Panneau liste + marquer lu
 */
(function (global) {
  "use strict";

  var VERSION = "224.0.0-local-notifications";
  var READ_KEY = "sycam_notif_read_v224";
  var EXTRA_KEY = "sycam_notif_extra_v224";

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function toast(msg) {
    if (typeof global.showToast === "function") {
      try {
        global.showToast(msg);
        return;
      } catch (e) {}
    }
  }
  function load(key, fb) {
    try {
      var v = JSON.parse(localStorage.getItem(key) || "null");
      return v == null ? fb : v;
    } catch (e) {
      return fb;
    }
  }
  function save(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) {}
  }

  function readSet() {
    return load(READ_KEY, {});
  }

  function markRead(id) {
    var r = readSet();
    r[id] = true;
    save(READ_KEY, r);
  }

  function markAllRead(ids) {
    var r = readSet();
    (ids || []).forEach(function (id) {
      r[id] = true;
    });
    save(READ_KEY, r);
  }

  function pushNotif(n) {
    var list = load(EXTRA_KEY, []);
    list.unshift(
      Object.assign(
        {
          id: "x_" + Date.now().toString(36),
          at: new Date().toISOString(),
          type: "info",
          title: "Notification",
          body: ""
        },
        n
      )
    );
    save(EXTRA_KEY, list.slice(0, 50));
    refreshBadge();
    return list[0];
  }

  function collect() {
    var items = [];
    var read = readSet();

    // Extra / system
    load(EXTRA_KEY, []).forEach(function (n) {
      items.push({
        id: n.id,
        type: n.type || "info",
        title: n.title,
        body: n.body,
        at: n.at,
        action: n.action || null
      });
    });

    // Publications
    try {
      load("sycam_publish_log_v221", []).forEach(function (p, i) {
        items.push({
          id: "pub_" + (p.at || i),
          type: "publish",
          title: p.ok ? "Publication réussie" : "Publication",
          body: (p.type || "") + " · " + (p.title || ""),
          at: p.at,
          action: "home"
        });
      });
    } catch (e) {}

    // Stories
    try {
      if (global.SycamV223 && global.SycamV223.getStories) {
        global.SycamV223.getStories().forEach(function (s) {
          items.push({
            id: "st_" + s.id,
            type: "story",
            title: "Story active",
            body: (s.text || "Photo").slice(0, 80),
            at: new Date(s.createdAt).toISOString(),
            action: "stories"
          });
        });
      }
    } catch (e) {}

    // Network messages (last per peer)
    try {
      var msgs = load("sycam_network_msgs_v222", {});
      Object.keys(msgs).forEach(function (peer) {
        var arr = msgs[peer] || [];
        var last = arr[arr.length - 1];
        if (!last || last.fromMe) return;
        items.push({
          id: "msg_" + peer + "_" + last.id,
          type: "message",
          title: "Message · " + peer,
          body: String(last.text || "").slice(0, 100),
          at: last.at,
          action: "network",
          peerId: peer
        });
      });
    } catch (e) {}

    // Gates
    try {
      load("sycam_gate_log_v213", []).slice(0, 10).forEach(function (g, i) {
        items.push({
          id: "gate_" + (g.at || i),
          type: "gate",
          title: "Gate · " + (g.status || ""),
          body: String(g.action || ""),
          at: g.at,
          action: "gates"
        });
      });
    } catch (e) {}

    // Legal audit sample
    try {
      load("sycam_legal_audit_v212", []).slice(0, 5).forEach(function (a, i) {
        items.push({
          id: "leg_" + (a.timestamp || i),
          type: "legal",
          title: "Conformité",
          body: String(a.type || ""),
          at: a.timestamp,
          action: "legal"
        });
      });
    } catch (e) {}

    items.sort(function (a, b) {
      return String(b.at || "").localeCompare(String(a.at || ""));
    });

    items.forEach(function (n) {
      n.unread = !read[n.id];
    });

    return items.slice(0, 80);
  }

  function unreadCount() {
    return collect().filter(function (n) {
      return n.unread;
    }).length;
  }

  function ensureStyles() {
    if ($("sycam-v224-css")) return;
    var s = document.createElement("style");
    s.id = "sycam-v224-css";
    s.textContent = [
      "#v219Bell{position:relative}",
      "#v224Badge{position:absolute;top:4px;right:4px;min-width:16px;height:16px;padding:0 4px;border-radius:999px;background:#ef4444;color:#fff;font-size:10px;font-weight:800;line-height:16px;text-align:center;display:none}",
      "#v224Badge.on{display:block}",
      "#v224Panel{position:fixed;top:0;right:0;width:min(100%,380px);height:100%;z-index:180;background:#0b1220;color:#e2e8f0;box-shadow:-8px 0 24px rgba(0,0,0,.4);display:none;flex-direction:column;padding-top:env(safe-area-inset-top,0px)}",
      "#v224Panel.on{display:flex}",
      "#v224Panel .hd{display:flex;align-items:center;justify-content:space-between;padding:14px;border-bottom:1px solid #1f2937}",
      "#v224Panel .hd h2{margin:0;font-size:16px;color:#fff}",
      "#v224Panel .hd button{border:0;background:#1f2937;color:#fff;border-radius:10px;padding:8px 12px;font-weight:700;cursor:pointer}",
      "#v224Panel .list{flex:1;overflow-y:auto;padding:8px 12px 24px}",
      ".v224-item{padding:12px;border-radius:12px;background:#111827;border:1px solid #1f2937;margin-bottom:8px;cursor:pointer}",
      ".v224-item.unread{border-color:#0d7377}",
      ".v224-item .t{font-size:13px;font-weight:800;color:#fff}",
      ".v224-item .b{font-size:12px;color:#94a3b8;margin-top:4px}",
      ".v224-item .m{font-size:10px;color:#64748b;margin-top:6px}",
      ".v224-empty{text-align:center;padding:40px 16px;color:#94a3b8;font-size:13px}"
    ].join("");
    document.head.appendChild(s);
  }

  function refreshBadge() {
    ensureStyles();
    var bell = $("v219Bell");
    if (!bell) return;
    var badge = $("v224Badge");
    if (!badge) {
      badge = document.createElement("span");
      badge.id = "v224Badge";
      bell.style.position = "relative";
      bell.appendChild(badge);
    }
    var n = unreadCount();
    if (n > 0) {
      badge.textContent = n > 99 ? "99+" : String(n);
      badge.classList.add("on");
    } else {
      badge.classList.remove("on");
    }
  }

  function ensurePanel() {
    if ($("v224Panel")) return $("v224Panel");
    var p = document.createElement("div");
    p.id = "v224Panel";
    p.innerHTML =
      '<div class="hd"><h2>Notifications</h2><div><button type="button" id="v224ReadAll">Tout lu</button> <button type="button" id="v224Close">Fermer</button></div></div>' +
      '<div class="list" id="v224List"></div>';
    document.body.appendChild(p);
    $("v224Close").onclick = closePanel;
    $("v224ReadAll").onclick = function () {
      markAllRead(
        collect().map(function (n) {
          return n.id;
        })
      );
      paintList();
      refreshBadge();
    };
    return p;
  }

  function paintList() {
    var list = $("v224List");
    if (!list) return;
    var items = collect();
    if (!items.length) {
      list.innerHTML = '<div class="v224-empty">Aucune notification</div>';
      return;
    }
    list.innerHTML = items
      .map(function (n) {
        return (
          '<div class="v224-item' +
          (n.unread ? " unread" : "") +
          '" data-id="' +
          esc(n.id) +
          '" data-action="' +
          esc(n.action || "") +
          '" data-peer="' +
          esc(n.peerId || "") +
          '"><div class="t">' +
          esc(n.title) +
          '</div><div class="b">' +
          esc(n.body) +
          '</div><div class="m">' +
          esc((n.at || "").replace("T", " ").slice(0, 19)) +
          " · " +
          esc(n.type) +
          "</div></div>"
        );
      })
      .join("");
    list.querySelectorAll(".v224-item").forEach(function (el) {
      el.onclick = function () {
        markRead(el.getAttribute("data-id"));
        var act = el.getAttribute("data-action");
        var peer = el.getAttribute("data-peer");
        closePanel();
        refreshBadge();
        if (act === "home" && global.SycamV219) global.SycamV219.openMobileHome();
        else if (act === "network" && global.SycamV222)
          global.SycamV222.openNetwork(peer ? { peerId: peer } : {});
        else if (act === "gates" && global.SycamV213) global.SycamV213.openGates();
        else if (act === "legal" && global.SycamV212) global.SycamV212.openLegal();
        else if (act === "stories" && global.SycamV223) global.SycamV223.openViewer(0);
      };
    });
  }

  function openPanel() {
    ensureStyles();
    ensurePanel();
    paintList();
    $("v224Panel").classList.add("on");
    refreshBadge();
  }

  function closePanel() {
    var p = $("v224Panel");
    if (p) p.classList.remove("on");
  }

  function wireBell() {
    var bell = $("v219Bell");
    if (!bell || bell.__v224) return;
    bell.__v224 = true;
    bell.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();
      openPanel();
    };
  }

  function boot() {
    ensureStyles();
    setTimeout(function () {
      wireBell();
      refreshBadge();
    }, 300);
    setTimeout(function () {
      wireBell();
      refreshBadge();
    }, 1000);
    // welcome notif once per session
    try {
      if (!sessionStorage.getItem("sycam_v224_hello")) {
        sessionStorage.setItem("sycam_v224_hello", "1");
        pushNotif({
          type: "info",
          title: "SYCAM-PUB prêt",
          body: "Notifications locales actives (pubs, messages, conformité).",
          action: "home"
        });
      }
    } catch (e) {}

    if (global.SycamV205 && global.SycamV205.MANIFESTS) {
      global.SycamV205.MANIFESTS["sycam-v224"] = {
        id: "sycam-v224",
        version: VERSION,
        global: "SycamV224",
        requires: ["sycam-v223"],
        provides: ["notif.center", "notif.badge"],
        modifies: [],
        routes: ["notifications", "notifs"],
        storage: [READ_KEY, EXTRA_KEY],
        events: [],
        permissions: ["notif.local"],
        adr: ["ADR-026"]
      };
    }
    if (global.SycamV204 && global.SycamV204.DECLARED_DEPS) {
      global.SycamV204.DECLARED_DEPS.SycamV224 = ["SycamV223"];
    }
    if (typeof global.go === "function" && !global.__sycamV224Go) {
      global.__sycamV224Go = true;
      var orig = global.go;
      global.go = function (name) {
        var n = String(name || "").toLowerCase();
        if (n === "notifications" || n === "notifs") {
          openPanel();
          return;
        }
        return orig.apply(this, arguments);
      };
    }
    // periodic badge refresh
    setInterval(refreshBadge, 15000);
    console.log("[V224] Notifications", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV224 = {
    version: VERSION,
    collect: collect,
    openPanel: openPanel,
    closePanel: closePanel,
    refreshBadge: refreshBadge,
    pushNotif: pushNotif,
    unreadCount: unreadCount
  };
})(typeof window !== "undefined" ? window : this);
