/*! SYCAM V219 — sycam-v219-mobile-shell.js
 * Shell mobile responsive + Mission Control
 * Nav bas : Accueil · Explorer · Publier · Réseau · Plus
 * Disposition professionnelle, touch targets, safe-area
 */
(function (global) {
  "use strict";

  var VERSION = "219.0.0-mobile-shell";
  var NAV_KEY = "sycam_mobile_nav_v219";

  function $(id) {
    return document.getElementById(id);
  }
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function toast(msg) {
    if (typeof global.showToast === "function") {
      try {
        global.showToast(msg);
        return;
      } catch (e) {}
    }
    var t = $("toast");
    if (t) {
      t.textContent = msg;
      t.classList.add("on");
      setTimeout(function () {
        t.classList.remove("on");
      }, 2000);
    }
  }

  function ensureCss() {
    if (document.getElementById("sycam-v219-css-link")) return;
    var link = document.createElement("link");
    link.id = "sycam-v219-css-link";
    link.rel = "stylesheet";
    link.href = "assets/css/sycam-v219-mobile-responsive.css";
    document.head.appendChild(link);
  }

  function showPage(id) {
    document.querySelectorAll("section.page,.page").forEach(function (p) {
      p.classList.remove("on");
      if (p.style) p.style.display = "none";
    });
    var page = $(id);
    if (!page) {
      page = document.createElement("section");
      page.id = id;
      page.className = "page";
      (document.querySelector("main") || document.body).appendChild(page);
    }
    page.style.display = "block";
    page.classList.add("on");
    return page;
  }

  function setNavActive(name) {
    try {
      localStorage.setItem(NAV_KEY, name);
    } catch (e) {}
    document.querySelectorAll(".sycam-v219-bottom-nav button").forEach(function (b) {
      b.classList.toggle("on", b.getAttribute("data-nav") === name);
    });
  }

  function goModule(name) {
    name = String(name || "").toLowerCase();
    if (typeof global.go === "function") {
      try {
        global.go(name);
        return;
      } catch (e) {}
    }
    var map = {
      home: openMobileHome,
      accueil: openMobileHome,
      explorer: function () {
        if (global.SycamV210) global.SycamV210.openNexusSoftware("mesh");
        else toast("Explorer");
      },
      publish: function () {
        if (global.SycamV210)
          global.SycamV210.execute("publication.create", { title: "" }, { force: true });
        else toast("Publier");
      },
      reseau: function () {
        toast("Réseau — module social");
      },
      plus: openPlusMenu,
      mission: openMissionControl,
      labready: function () {
        if (global.SycamV214) global.SycamV214.openLabReady();
      },
      gates: function () {
        if (global.SycamV213) global.SycamV213.openGates();
      },
      device: function () {
        if (global.SycamV217) global.SycamV217.openDevice();
      },
      queue: function () {
        if (global.SycamV218) global.SycamV218.openQueue();
      },
      gateway: function () {
        if (global.SycamV215) global.SycamV215.openGateway();
      },
      legal: function () {
        if (global.SycamV212) global.SycamV212.openLegal();
      },
      harden: function () {
        if (global.SycamV216) global.SycamV216.openHarden();
      },
      jarvis: function () {
        if (global.SycamV209) global.SycamV209.openNexus();
        else if (global.SycamV210) global.SycamV210.openNexusSoftware();
      },
      bridge: function () {
        if (global.SycamV211) global.SycamV211.openBridge();
      }
    };
    if (map[name]) map[name]();
  }

  function ensureChrome() {
    document.body.classList.add("sycam-v219-mobile");

    if (!$("sycam-v219-header")) {
      var header = document.createElement("div");
      header.id = "sycam-v219-header";
      header.className = "sycam-v219-header";
      header.innerHTML =
        '<span class="brand">SYCAM-PUB</span>' +
        '<span class="status-pill" id="v219OnlinePill">Local</span>' +
        '<button type="button" class="icon-btn" id="v219Bell" aria-label="Notifications">🔔</button>' +
        '<button type="button" class="icon-btn" id="v219JarvisBtn" aria-label="JARVIS">AI</button>';
      document.body.insertBefore(header, document.body.firstChild);
      $("v219Bell").onclick = function () {
        toast("Notifications");
      };
      $("v219JarvisBtn").onclick = function () {
        goModule("jarvis");
      };
    }

    if (!$("sycam-v219-bottom-nav")) {
      var nav = document.createElement("nav");
      nav.id = "sycam-v219-bottom-nav";
      nav.className = "sycam-v219-bottom-nav";
      nav.setAttribute("aria-label", "Navigation principale");
      nav.innerHTML =
        '<button type="button" data-nav="home"><span class="ico">🏠</span>Accueil</button>' +
        '<button type="button" data-nav="explorer"><span class="ico">🔍</span>Explorer</button>' +
        '<button type="button" data-nav="publish" class="publish-fab"><span class="ico">＋</span>Publier</button>' +
        '<button type="button" data-nav="reseau"><span class="ico">👥</span>Réseau</button>' +
        '<button type="button" data-nav="plus"><span class="ico">☰</span>Plus</button>';
      document.body.appendChild(nav);
      nav.querySelectorAll("button").forEach(function (b) {
        b.onclick = function () {
          var n = b.getAttribute("data-nav");
          setNavActive(n);
          if (n === "home") openMobileHome();
          else if (n === "plus") openPlusMenu();
          else goModule(n);
        };
      });
    }

    // online pill from gateway/device
    try {
      var base =
        global.SycamV215 && global.SycamV215.getApiBase ? global.SycamV215.getApiBase() : "";
      var st = global.SycamV217 && global.SycamV217.getState ? global.SycamV217.getState() : null;
      var pill = $("v219OnlinePill");
      if (pill) {
        if (st && st.attached) pill.textContent = "Appareil";
        else if (base) pill.textContent = "API";
        else pill.textContent = "Local";
      }
    } catch (e) {}
  }

  function sampleFeed() {
    return [
      {
        tag: "News",
        title: "Actualités scientifiques & partenaires",
        meta: "SYCAM-PUB · flux",
        excerpt: "Les actualités membres s’affichent ici. Branchez HAL / RSS via NEXUS."
      },
      {
        tag: "Pub",
        title: "Vos publications et dépôts",
        meta: "Bibliothèque · local",
        excerpt: "Publiez un article, dataset ou PDF depuis le bouton central."
      },
      {
        tag: "Lab",
        title: "Workspace & carnet de labo",
        meta: "Projets",
        excerpt: "Kanban, notes et ressources interconnectées via NEXUS."
      }
    ];
  }

  function openMobileHome() {
    ensureChrome();
    setNavActive("home");
    var page = showPage("pg-mobilehome");
    var feed = sampleFeed();
    page.innerHTML =
      '<h1>Accueil</h1>' +
      '<p class="v219-sub">Science · Innovation · Impact — mobile first</p>' +
      '<input class="v219-search" id="v219Search" placeholder="Rechercher dans SYCAM-PUB…" type="search" enterkeyhint="search"/>' +
      '<div class="v219-chip-row">' +
      '<button type="button" class="v219-chip on" data-f="tous">Tous</button>' +
      '<button type="button" class="v219-chip" data-f="pub">Publications</button>' +
      '<button type="button" class="v219-chip" data-f="news">Actualités</button>' +
      "</div>" +
      '<div class="v219-card"><h3>Vue d’ensemble</h3>' +
      '<div class="v219-grid-2 v219-grid-4">' +
      '<div class="v219-kpi"><div class="n" id="v219K1">—</div><div class="l">Projets</div></div>' +
      '<div class="v219-kpi"><div class="n" id="v219K2">—</div><div class="l">Publications</div></div>' +
      '<div class="v219-kpi"><div class="n" id="v219K3">—</div><div class="l">Ressources</div></div>' +
      '<div class="v219-kpi"><div class="n" id="v219K4">—</div><div class="l">Score labo</div></div>' +
      "</div></div>" +
      '<div class="v219-card"><h3>Accès rapides</h3>' +
      '<div class="v219-grid-3">' +
      '<button type="button" class="v219-tile" data-go-m="jarvis"><span class="t-ico">🤖</span><span class="t-label">JARVIS</span><span class="t-hint">Assistant</span></button>' +
      '<button type="button" class="v219-tile" data-go-m="bridge"><span class="t-ico">📥</span><span class="t-label">Import</span><span class="t-hint">Data Bridge</span></button>' +
      '<button type="button" class="v219-tile" data-go-m="mission"><span class="t-ico">🎛️</span><span class="t-label">Mission</span><span class="t-hint">Contrôle</span></button>' +
      "</div></div>" +
      '<div id="v219Feed"></div>';

    var feedEl = $("v219Feed");
    feedEl.innerHTML = feed
      .map(function (f) {
        return (
          '<article class="v219-feed-card"><span class="tag">' +
          esc(f.tag) +
          "</span><h4>" +
          esc(f.title) +
          '</h4><div class="meta">' +
          esc(f.meta) +
          '</div><div class="excerpt">' +
          esc(f.excerpt) +
          "</div></article>"
        );
      })
      .join("");

    // KPIs soft
    try {
      var res =
        global.SycamV210 && global.SycamV210.listResources
          ? global.SycamV210.listResources().length
          : 0;
      $("v219K3").textContent = String(res);
      if (global.SycamV214 && global.SycamV214.score) {
        $("v219K4").textContent = String(global.SycamV214.score().score || 0);
      }
      $("v219K1").textContent = "0";
      $("v219K2").textContent = String(res);
    } catch (e) {}

    page.querySelectorAll("[data-go-m]").forEach(function (b) {
      b.onclick = function () {
        goModule(b.getAttribute("data-go-m"));
      };
    });
    page.querySelectorAll(".v219-chip").forEach(function (c) {
      c.onclick = function () {
        page.querySelectorAll(".v219-chip").forEach(function (x) {
          x.classList.remove("on");
        });
        c.classList.add("on");
      };
    });
    $("v219Search").onkeydown = function (ev) {
      if (ev.key === "Enter") {
        toast("Recherche : " + ($("v219Search").value || "").slice(0, 40));
        goModule("explorer");
      }
    };
  }

  function openPlusMenu() {
    ensureChrome();
    setNavActive("plus");
    var page = showPage("pg-plusmenu");
    page.innerHTML =
      "<h1>Plus</h1>" +
      '<p class="v219-sub">Modules · gouvernance · appareil — une destination claire</p>' +
      '<div class="v219-card"><h3>Travail scientifique</h3>' +
      '<div class="v219-grid-2">' +
      tile("jarvis", "🤖", "JARVIS", "Orchestrateur") +
      tile("bridge", "📥", "Data Bridge", "Import local") +
      tile("explorer", "🔍", "Explorer", "Recherche / Mesh") +
      tile("queue", "📬", "File locale", "Termux ↔ UI") +
      "</div></div>" +
      '<div class="v219-card"><h3>Gouvernance & labo</h3>' +
      '<div class="v219-grid-2">' +
      tile("legal", "⚖️", "Conformité", "Mandat / droits") +
      tile("gates", "🛡️", "Gates", "Écritures L2/L3") +
      tile("labready", "🏛️", "Labo prêt", "Score institution") +
      tile("harden", "🔒", "Durcissement", "Secrets / API") +
      "</div></div>" +
      '<div class="v219-card"><h3>Appareil</h3>' +
      '<div class="v219-grid-2">' +
      tile("device", "📱", "Rattachement", "Termux local") +
      tile("gateway", "🌐", "Passerelle", "/api/jarvis") +
      tile("mission", "🎛️", "Mission Control", "Vue unique") +
      "</div></div>";

    page.querySelectorAll("[data-go-m]").forEach(function (b) {
      b.onclick = function () {
        goModule(b.getAttribute("data-go-m"));
      };
    });
  }

  function tile(id, ico, label, hint) {
    return (
      '<button type="button" class="v219-tile" data-go-m="' +
      esc(id) +
      '"><span class="t-ico">' +
      ico +
      '</span><span class="t-label">' +
      esc(label) +
      '</span><span class="t-hint">' +
      esc(hint) +
      "</span></button>"
    );
  }

  function openMissionControl() {
    ensureChrome();
    var page = showPage("pg-mission");
    var mandate =
      global.SycamV212 && global.SycamV212.getMandate && global.SycamV212.getMandate();
    var st = global.SycamV217 && global.SycamV217.getState ? global.SycamV217.getState() : {};
    var lab =
      global.SycamV214 && global.SycamV214.score ? global.SycamV214.score() : { score: "—" };
    var gatesOn =
      !!(global.SycamV210 && global.SycamV210.__gated213) &&
      !!(global.SycamV211 && global.SycamV211.__gated213);

    page.innerHTML =
      "<h1>Mission Control</h1>" +
      '<p class="v219-sub">Tableau unique · labo · conformité · appareil · file</p>' +
      '<div class="v219-card"><h3>État plateforme</h3>' +
      '<div class="v219-row"><span>Score labo</span><span class="v219-ok">' +
      esc(String(lab.score)) +
      "/100</span></div>" +
      '<div class="v219-row"><span>Mandat</span><span class="' +
      (mandate && mandate.accepted ? "v219-ok" : "v219-no") +
      '">' +
      (mandate && mandate.accepted ? "accepté" : "requis") +
      "</span></div>" +
      '<div class="v219-row"><span>Gates</span><span class="' +
      (gatesOn ? "v219-ok" : "v219-no") +
      '">' +
      (gatesOn ? "actifs" : "inactifs") +
      "</span></div>" +
      '<div class="v219-row"><span>Appareil</span><span>' +
      esc(st.mode || "browser-only") +
      "</span></div></div>" +
      '<div class="v219-card"><h3>Lancer</h3>' +
      '<div class="v219-grid-2">' +
      tile("labready", "🏛️", "Labo prêt", "Checklist") +
      tile("gates", "🛡️", "Gates", "Journal") +
      tile("device", "📱", "Appareil", "Attach") +
      tile("queue", "📬", "File", "Import JSON") +
      tile("gateway", "🌐", "API", "healthz") +
      tile("harden", "🔒", "Harden", "Scan") +
      "</div></div>" +
      '<div class="v219-actions">' +
      '<button type="button" class="primary" id="v219Home">Retour Accueil</button>' +
      '<button type="button" id="v219Legal">Conformité</button>' +
      "</div>";

    page.querySelectorAll("[data-go-m]").forEach(function (b) {
      b.onclick = function () {
        goModule(b.getAttribute("data-go-m"));
      };
    });
    $("v219Home").onclick = openMobileHome;
    $("v219Legal").onclick = function () {
      goModule("legal");
    };
  }

  function boot() {
    ensureCss();
    ensureChrome();

    if (global.SycamV205 && global.SycamV205.MANIFESTS) {
      global.SycamV205.MANIFESTS["sycam-v219"] = {
        id: "sycam-v219",
        version: VERSION,
        global: "SycamV219",
        requires: ["sycam-v218"],
        provides: ["ui.mobile", "ui.mission", "ui.bottomnav"],
        modifies: [],
        routes: ["mobilehome", "mission", "plus"],
        storage: [NAV_KEY],
        events: [],
        permissions: ["ui.shell"],
        adr: ["ADR-021"]
      };
    }
    if (global.SycamV204 && global.SycamV204.DECLARED_DEPS) {
      global.SycamV204.DECLARED_DEPS.SycamV219 = ["SycamV218"];
    }
    if (global.SycamV192 && global.SycamV192.ALIAS) {
      global.SycamV192.ALIAS.mobilehome = "mobilehome";
      global.SycamV192.ALIAS.mission = "mission";
      global.SycamV192.ALIAS.plus = "plus";
    }

    document.addEventListener(
      "click",
      function (e) {
        var el = e.target && e.target.closest && e.target.closest("[data-go]");
        if (!el) return;
        var g = String(el.getAttribute("data-go") || "").toLowerCase();
        if (g === "mobilehome" || g === "mission" || g === "plus") {
          e.preventDefault();
          e.stopPropagation();
          if (g === "mission") openMissionControl();
          else if (g === "plus") openPlusMenu();
          else openMobileHome();
        }
      },
      true
    );

    if (typeof global.go === "function" && !global.__sycamV219Go) {
      global.__sycamV219Go = true;
      var orig = global.go;
      global.go = function (name) {
        var n = String(name || "").toLowerCase();
        if (n === "mobilehome" || n === "accueil" || n === "home") {
          openMobileHome();
          return;
        }
        if (n === "mission") {
          openMissionControl();
          return;
        }
        if (n === "plus") {
          openPlusMenu();
          return;
        }
        return orig.apply(this, arguments);
      };
    }

    // Auto-open mobile home on small screens first visit
    try {
      if (window.innerWidth < 768 && !sessionStorage.getItem("sycam_v219_booted")) {
        sessionStorage.setItem("sycam_v219_booted", "1");
        setTimeout(openMobileHome, 200);
      }
    } catch (e) {}

    console.log("[V219] Mobile shell", VERSION);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV219 = {
    version: VERSION,
    openMobileHome: openMobileHome,
    openPlusMenu: openPlusMenu,
    openMissionControl: openMissionControl,
    ensureChrome: ensureChrome
  };
})(typeof window !== "undefined" ? window : this);
