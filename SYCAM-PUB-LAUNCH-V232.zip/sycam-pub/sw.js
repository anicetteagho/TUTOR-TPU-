/* SYCAM-PUB V230 clean shell */
const CACHE = "sycam-pub-v232-clean";
const PRECACHE = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./icon.svg",
  "./assets/css/sycam-v219-mobile-responsive.css",
  "./assets/js/sycam-core-minimal.js",
  "./assets/js/sycam-v232-hal-client.js",
  "./assets/js/sycam-v219-mobile-shell.js",
  "./assets/js/sycam-v220-live-feed-explorer.js",
  "./assets/js/sycam-v221-mobile-publish.js",
  "./assets/js/sycam-v222-mobile-network.js",
  "./assets/js/sycam-v223-stories-status.js",
  "./assets/js/sycam-v224-local-notifications.js",
  "./assets/js/sycam-v225-demo-walkthrough.js",
  "./assets/js/sycam-v226-offline-mode.js",
  "./assets/js/sycam-v227-pwa-register.js",
  "./assets/js/sycam-v228-plus-menu-hub.js",
  "./assets/js/sycam-v229-onboarding.js",
  "./assets/js/sycam-v230-home-shortcuts-news.js",
  "./assets/js/sycam-v231-health-qa.js"
];
self.addEventListener("install", function (e) {
  e.waitUntil(
    caches.open(CACHE).then(function (c) {
      return c.addAll(PRECACHE).catch(function () {});
    }).then(function () { return self.skipWaiting(); })
  );
});
self.addEventListener("activate", function (e) {
  e.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); }));
    }).then(function () { return self.clients.claim(); })
  );
});
self.addEventListener("fetch", function (e) {
  if (e.request.method !== "GET") return;
  var url = new URL(e.request.url);
  if (url.origin !== self.location.origin) return;
  e.respondWith(
    caches.match(e.request).then(function (cached) {
      var fetched = fetch(e.request).then(function (res) {
        if (res && res.ok) {
          var copy = res.clone();
          caches.open(CACHE).then(function (c) { c.put(e.request, copy); });
        }
        return res;
      }).catch(function () { return cached; });
      return cached || fetched;
    })
  );
});
