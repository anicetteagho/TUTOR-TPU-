/*! SYCAM V232 — Client HAL public (pack clean)
 * Recherche réelle api.archives-ouvertes.fr
 */
(function (global) {
  "use strict";

  var VERSION = "232.0.0-hal-client";
  var CACHE_KEY = "sycam_hal_cache_v232";
  var API = "https://api.archives-ouvertes.fr/search/";

  function load(k, fb) {
    try {
      var v = JSON.parse(localStorage.getItem(k) || "null");
      return v == null ? fb : v;
    } catch (e) {
      return fb;
    }
  }
  function save(k, v) {
    try {
      localStorage.setItem(k, JSON.stringify(v));
    } catch (e) {}
  }

  function mapDoc(d) {
    var title = d.title_s || d.label_s || d.title || "Document HAL";
    if (Array.isArray(title)) title = title[0];
    var abs = d.abstract_s || d.description_s || "";
    if (Array.isArray(abs)) abs = abs[0];
    var authors = d.authFullName_s || d.author_s || [];
    if (!Array.isArray(authors)) authors = authors ? [authors] : [];
    var uri = d.uri_s || d.link_s || (d.halId_s ? "https://hal.science/" + d.halId_s : "");
    if (Array.isArray(uri)) uri = uri[0];
    return {
      halId: d.halId_s || d.docid || "",
      title: String(title),
      abstract: String(abs || "").slice(0, 400),
      authors: authors,
      producedDate: d.producedDateY_i || d.producedDate_s || "",
      uri: uri,
      citationFull: authors.slice(0, 3).join(", ") + (authors.length ? " — " : "") + title
    };
  }

  function searchHal(q, filter, rows) {
    q = String(q || "science").trim() || "science";
    rows = rows || 12;
    var cacheKey = q + "|" + rows;
    var cache = load(CACHE_KEY, {});
    if (cache[cacheKey] && cache[cacheKey].at && Date.now() - cache[cacheKey].at < 10 * 60 * 1000) {
      return Promise.resolve(cache[cacheKey].pack);
    }

    var params = new URLSearchParams({
      q: q,
      wt: "json",
      rows: String(rows),
      fl: "title_s,abstract_s,uri_s,authFullName_s,producedDateY_i,halId_s,docid,label_s"
    });

    return fetch(API + "?" + params.toString(), {
      method: "GET",
      headers: { Accept: "application/json" }
    })
      .then(function (res) {
        if (!res.ok) throw new Error("HAL HTTP " + res.status);
        return res.json();
      })
      .then(function (data) {
        var docs = (((data || {}).response || {}).docs) || [];
        var pack = {
          q: q,
          numFound: ((data.response || {}).numFound) || docs.length,
          docs: docs.map(mapDoc)
        };
        cache[cacheKey] = { at: Date.now(), pack: pack };
        var keys = Object.keys(cache);
        if (keys.length > 20) {
          keys.slice(0, keys.length - 15).forEach(function (k) {
            delete cache[k];
          });
        }
        save(CACHE_KEY, cache);
        return pack;
      })
      .catch(function (err) {
        console.warn("[V232] HAL", err);
        // fallback sample if offline / CORS
        return {
          q: q,
          numFound: 0,
          docs: [],
          error: String(err.message || err),
          offline: true
        };
      });
  }

  // Expose as V202 for V220.fromHal
  global.SycamV202 = global.SycamV202 || {};
  global.SycamV202.searchHal = searchHal;
  global.SycamV202.version = VERSION;

  // Patch V210.execute hal.search
  if (global.SycamV210 && global.SycamV210.execute) {
    var origExec = global.SycamV210.execute.bind(global.SycamV210);
    global.SycamV210.execute = function (action, payload, opts) {
      if (action === "hal.search") {
        return searchHal((payload && payload.q) || "science", "", 12).then(function (pack) {
          return {
            ok: true,
            data: {
              docs: pack.docs,
              resources: (pack.docs || []).map(function (d) {
                return {
                  type: "hal",
                  title: d.title,
                  source: "hal",
                  url: d.uri,
                  meta: { abstract: d.abstract, authors: d.authors }
                };
              })
            }
          };
        });
      }
      return origExec(action, payload, opts);
    };
  }

  function boot() {
    console.log("[V232] HAL client", VERSION);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.SycamV232 = {
    version: VERSION,
    searchHal: searchHal
  };
})(typeof window !== "undefined" ? window : this);
